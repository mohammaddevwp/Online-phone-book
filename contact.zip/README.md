# دفترچه تلفن آنلاین

یک برنامه وب پیشرفته برای مدیریت مخاطبین با PHP و MySQL

## ویژگی‌ها

- ✨ طراحی واکنش‌گرا با Tailwind CSS
- 🎨 انیمیشن‌های زیبا با Animate.css
- 🔍 جستجوی لحظه‌ای
- 📱 سازگار با موبایل و دسکتاپ
- 🔒 امنیت بالا با PDO
- ⚡ عملکرد سریع با AJAX

## پیش‌نیازها

- PHP 8.0 یا بالاتر
- MySQL 5.7 یا بالاتر
- وب سرور (Apache/Nginx)

## نصب و راه‌اندازی

1. ابتدا دیتابیس را ایجاد کنید:

```sql
CREATE DATABASE phonebook CHARACTER SET utf8mb4 COLLATE utf8mb4_persian_ci;
```

2. فایل `sql/database.sql` را در دیتابیس اجرا کنید.

3. تنظیمات اتصال به دیتابیس را در فایل `includes/db.php` ویرایش کنید:

```php
define('DB_HOST', 'localhost');
define('DB_NAME', 'phonebook');
define('DB_USER', 'root');
define('DB_PASS', '');
```

4. پروژه را در مسیر وب سرور قرار دهید.

5. به آدرس `http://localhost/phonebook` مراجعه کنید.

## ساختار پروژه

```
/phonebook-app/
│
├── index.php ← صفحه اصلی
├── api/ ← API های برنامه
├── assets/ ← فایل‌های استاتیک
├── includes/ ← فایل‌های PHP مشترک
└── sql/ ← اسکریپت‌های دیتابیس
```

## امنیت

- استفاده از PDO برای جلوگیری از SQL Injection
- اعتبارسنجی داده‌ها در سمت سرور
- امن‌سازی خروجی HTML
- استفاده از Prepared Statements

## توسعه

برای توسعه پروژه:

1. از Composer برای مدیریت وابستگی‌ها استفاده کنید
2. از ESLint برای کدهای JavaScript استفاده کنید
3. از PHP_CodeSniffer برای استانداردهای PHP استفاده کنید

## مجوز

این پروژه تحت مجوز MIT منتشر شده است.
