<?php
require_once '../includes/functions.php';

header('Content-Type: application/json');

// دریافت داده‌های JSON
$data = json_decode(file_get_contents('php://input'), true);

// اعتبارسنجی داده‌ها
if (!validateName($data['name'])) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'نام باید حداقل ۲ کاراکتر باشد']);
    exit;
}

if (!validatePhone($data['phone'])) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'شماره تلفن باید ۱۱ رقم باشد']);
    exit;
}

if (!empty($data['email']) && !validateEmail($data['email'])) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'ایمیل نامعتبر است']);
    exit;
}

try {
    $success = addContact(
        $data['name'],
        $data['phone'],
        $data['email'] ?? '',
        $data['address'] ?? ''
    );
    
    if ($success) {
        echo json_encode(['success' => true]);
    } else {
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'خطا در افزودن مخاطب']);
    }
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'خطا در افزودن مخاطب']);
} 