<?php
require_once '../includes/functions.php';

header('Content-Type: application/json');

// دریافت داده‌های JSON
$data = json_decode(file_get_contents('php://input'), true);

// اعتبارسنجی داده‌ها
if (!isset($data['id'])) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'شناسه مخاطب الزامی است']);
    exit;
}

try {
    $success = deleteContact($data['id']);
    
    if ($success) {
        echo json_encode(['success' => true]);
    } else {
        http_response_code(500);
        echo json_encode(['success' => false, 'message' => 'خطا در حذف مخاطب']);
    }
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'خطا در حذف مخاطب']);
} 