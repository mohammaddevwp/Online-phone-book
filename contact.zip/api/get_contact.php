<?php
require_once '../includes/functions.php';

header('Content-Type: application/json');

$id = $_GET['id'] ?? null;

if (!$id) {
    http_response_code(400);
    echo json_encode(['error' => 'شناسه مخاطب الزامی است']);
    exit;
}

try {
    $contact = getContact($id);
    
    if ($contact) {
        echo json_encode($contact);
    } else {
        http_response_code(404);
        echo json_encode(['error' => 'مخاطب یافت نشد']);
    }
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'خطا در دریافت اطلاعات مخاطب']);
} 