<?php
require_once '../includes/functions.php';

header('Content-Type: application/json');

$query = $_GET['q'] ?? '';

if (strlen($query) < 2) {
    echo json_encode([]);
    exit;
}

try {
    $contacts = searchContacts($query);
    echo json_encode($contacts);
} catch (Exception $e) {
    http_response_code(500);
    echo json_encode(['error' => 'خطا در جستجوی مخاطبین']);
} 