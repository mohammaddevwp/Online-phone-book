// متغیرهای سراسری
let searchTimeout;
const modal = document.getElementById("contactModal");
const searchInput = document.getElementById("search");

// نمایش مودال افزودن مخاطب
function showAddContactModal() {
  document.getElementById("modalTitle").textContent = "افزودن مخاطب جدید";
  document.getElementById("contactForm").reset();
  document.getElementById("contactId").value = "";
  modal.classList.remove("hidden");
  modal.classList.add("flex");
}

// بستن مودال
function closeModal() {
  modal.classList.remove("flex");
  modal.classList.add("hidden");
}

// ویرایش مخاطب
async function editContact(id) {
  try {
    const response = await fetch(`api/get_contact.php?id=${id}`);
    const contact = await response.json();

    if (contact) {
      document.getElementById("modalTitle").textContent = "ویرایش مخاطب";
      document.getElementById("contactId").value = contact.id;
      document.getElementById("name").value = contact.name;
      document.getElementById("phone").value = contact.phone;
      document.getElementById("email").value = contact.email;
      document.getElementById("address").value = contact.address;

      modal.classList.remove("hidden");
      modal.classList.add("flex");
    }
  } catch (error) {
    showToast("خطا در دریافت اطلاعات مخاطب", "error");
  }
}

// حذف مخاطب
async function deleteContact(id) {
  if (confirm("آیا از حذف این مخاطب اطمینان دارید؟")) {
    try {
      const response = await fetch("api/delete_contact.php", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ id: Number(id) }),
      });

      const result = await response.json();

      if (result.success) {
        const row = document.querySelector(`tr[data-id='${id}']`);
        if (row) {
          row.classList.add("animate__fadeOut");
          setTimeout(() => row.remove(), 500);
        }
        showToast("مخاطب با موفقیت حذف شد", "success");
      } else {
        showToast(result.message || "خطا در حذف مخاطب", "error");
      }
    } catch (error) {
      showToast("خطا در حذف مخاطب", "error");
    }
  }
}

// مدیریت ارسال فرم
async function handleSubmit(event) {
  event.preventDefault();

  const formData = {
    id: document.getElementById("contactId").value,
    name: document.getElementById("name").value,
    phone: document.getElementById("phone").value,
    email: document.getElementById("email").value,
    address: document.getElementById("address").value,
  };

  try {
    const url = formData.id ? "api/edit_contact.php" : "api/add_contact.php";
    const response = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(formData),
    });

    const result = await response.json();

    if (result.success) {
      closeModal();
      showToast(
        formData.id ? "مخاطب با موفقیت ویرایش شد" : "مخاطب با موفقیت افزوده شد",
        "success"
      );
      setTimeout(() => window.location.reload(), 1000);
    } else {
      showToast(result.message || "خطا در ذخیره اطلاعات", "error");
    }
  } catch (error) {
    showToast("خطا در ذخیره اطلاعات", "error");
  }
}

// جستجوی لحظه‌ای
searchInput.addEventListener("input", (e) => {
  clearTimeout(searchTimeout);
  searchTimeout = setTimeout(async () => {
    const query = e.target.value.trim();
    if (query.length >= 2) {
      try {
        const response = await fetch(
          `api/search.php?q=${encodeURIComponent(query)}`
        );
        const contacts = await response.json();
        updateContactsTable(contacts);
      } catch (error) {
        showToast("خطا در جستجو", "error");
      }
    } else if (query.length === 0) {
      window.location.reload();
    }
  }, 300);
});

// به‌روزرسانی جدول مخاطبین
function updateContactsTable(contacts) {
  const tbody = document.getElementById("contactsTable");
  tbody.innerHTML = "";

  contacts.forEach((contact) => {
    const tr = document.createElement("tr");
    tr.className =
      "border-t border-gray-200 hover:bg-gray-50 animate__animated animate__fadeIn";
    tr.setAttribute("data-id", contact.id);

    tr.innerHTML = `
            <td class="p-4">${escapeHtml(contact.name)}</td>
            <td class="p-4">${escapeHtml(contact.phone)}</td>
            <td class="p-4">${escapeHtml(contact.email)}</td>
            <td class="p-4">${escapeHtml(contact.address)}</td>
            <td class="p-4">
                <button onclick="editContact(${contact.id})" 
                        class="text-blue-500 hover:text-blue-700 ml-2">
                    ویرایش
                </button>
                <button onclick="deleteContact(${contact.id})" 
                        class="text-red-500 hover:text-red-700">
                    حذف
                </button>
            </td>
        `;

    tbody.appendChild(tr);
  });
}

// نمایش پیام
function showToast(message, type = "success") {
  const toast = document.createElement("div");
  toast.className = `fixed bottom-4 right-4 p-4 rounded-lg text-white animate__animated animate__fadeIn ${
    type === "success" ? "bg-green-500" : "bg-red-500"
  }`;
  toast.textContent = message;

  document.body.appendChild(toast);

  setTimeout(() => {
    toast.classList.remove("animate__fadeIn");
    toast.classList.add("animate__fadeOut");
    setTimeout(() => toast.remove(), 500);
  }, 3000);
}

// امن‌سازی خروجی HTML
function escapeHtml(unsafe) {
  return unsafe
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}
