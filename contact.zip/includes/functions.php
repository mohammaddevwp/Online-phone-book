<?php
require_once 'db.php';

/**
 * اعتبارسنجی شماره تلفن
 */
function validatePhone($phone) {
    return preg_match('/^[0-9]{11}$/', $phone);
}

/**
 * اعتبارسنجی ایمیل
 */
function validateEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}

/**
 * اعتبارسنجی نام
 */
function validateName($name) {
    return strlen(trim($name)) >= 2;
}

/**
 * دریافت تمام مخاطبین
 */
function getAllContacts() {
    global $pdo;
    $stmt = $pdo->query("SELECT * FROM contacts ORDER BY name ASC");
    return $stmt->fetchAll();
}

/**
 * جستجوی مخاطبین
 */
function searchContacts($query) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT * FROM contacts WHERE name LIKE :query OR phone LIKE :query OR email LIKE :query ORDER BY name ASC");
    $stmt->execute(['query' => "%$query%"]);
    return $stmt->fetchAll();
}

/**
 * افزودن مخاطب جدید
 */
function addContact($name, $phone, $email, $address) {
    global $pdo;
    $stmt = $pdo->prepare("INSERT INTO contacts (name, phone, email, address) VALUES (:name, :phone, :email, :address)");
    return $stmt->execute([
        'name' => $name,
        'phone' => $phone,
        'email' => $email,
        'address' => $address
    ]);
}

/**
 * ویرایش مخاطب
 */
function editContact($id, $name, $phone, $email, $address) {
    global $pdo;
    $stmt = $pdo->prepare("UPDATE contacts SET name = :name, phone = :phone, email = :email, address = :address WHERE id = :id");
    return $stmt->execute([
        'id' => $id,
        'name' => $name,
        'phone' => $phone,
        'email' => $email,
        'address' => $address
    ]);
}

/**
 * حذف مخاطب
 */
function deleteContact($id) {
    global $pdo;
    $stmt = $pdo->prepare("DELETE FROM contacts WHERE id = :id");
    return $stmt->execute(['id' => $id]);
}

/**
 * دریافت اطلاعات یک مخاطب
 */
function getContact($id) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT * FROM contacts WHERE id = :id");
    $stmt->execute(['id' => $id]);
    return $stmt->fetch();
} 