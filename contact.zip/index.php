<?php
require_once 'includes/functions.php';
$contacts = getAllContacts();
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>دفترچه تلفن آنلاین</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body class="bg-gray-900 text-gray-100">
    <div class="container mx-auto px-4 py-8">
        <h1 class="text-3xl font-bold text-center mb-8 text-gray-100">دفترچه تلفن آنلاین</h1>
        
        <!-- جستجو -->
        <div class="mb-6">
            <input type="text" id="search" placeholder="جستجوی مخاطب..." 
                   class="w-full p-3 rounded-lg border border-gray-800 bg-gray-800 text-gray-100 focus:border-pink-500 focus:ring-2 focus:ring-pink-200">
        </div>

        <!-- دکمه افزودن مخاطب -->
        <div class="mb-6">
            <button class="custom-btn" onclick="showAddContactModal()">
                <span class="shadow"></span>
                <span class="edge"></span>
                <span class="front">افزودن مخاطب جدید</span>
            </button>
        </div>

        <!-- جدول مخاطبین -->
        <div class="bg-gray-800 rounded-lg shadow-lg overflow-hidden">
            <table class="w-full">
                <thead class="bg-gray-800">
                    <tr>
                        <th class="p-4 text-right text-gray-100">نام</th>
                        <th class="p-4 text-right text-gray-100">شماره تماس</th>
                        <th class="p-4 text-right text-gray-100">ایمیل</th>
                        <th class="p-4 text-right text-gray-100">آدرس</th>
                        <th class="p-4 text-right text-gray-100">عملیات</th>
                    </tr>
                </thead>
                <tbody id="contactsTable">
                    <?php foreach ($contacts as $contact): ?>
                    <tr data-id="<?= $contact['id'] ?>" class="border-t border-gray-800 hover:bg-gray-900 animate__animated animate__fadeIn">
                        <td class="p-4 text-gray-100"><?= htmlspecialchars($contact['name']) ?></td>
                        <td class="p-4 text-gray-100"><?= htmlspecialchars($contact['phone']) ?></td>
                        <td class="p-4 text-gray-100"><?= htmlspecialchars($contact['email']) ?></td>
                        <td class="p-4 text-gray-100"><?= htmlspecialchars($contact['address']) ?></td>
                        <td class="p-4">
                            <button class="custom-btn" onclick="editContact(<?= $contact['id'] ?>)">
                                <span class="shadow"></span>
                                <span class="edge"></span>
                                <span class="front">ویرایش</span>
                            </button>
                            <button class="custom-btn danger" onclick="deleteContact(<?= $contact['id'] ?>)">
                                <span class="shadow"></span>
                                <span class="edge"></span>
                                <span class="front">حذف</span>
                            </button>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- مودال افزودن/ویرایش مخاطب -->
    <div id="contactModal" class="fixed inset-0 bg-black bg-opacity-50 hidden items-center justify-center">
        <div class="bg-white rounded-lg p-8 w-full max-w-md">
            <h2 id="modalTitle" class="text-2xl font-bold mb-6 text-gray-100">افزودن مخاطب جدید</h2>
            <form id="contactForm" onsubmit="handleSubmit(event)">
                <input type="hidden" id="contactId">
                <div class="mb-4">
                    <label class="block mb-2">نام</label>
                    <input type="text" id="name" required
                           class="w-full p-2 border border-gray-800 rounded-lg bg-gray-800 text-gray-100 focus:border-pink-500 focus:ring-2 focus:ring-pink-200">
                </div>
                <div class="mb-4">
                    <label class="block mb-2">شماره تماس</label>
                    <input type="tel" id="phone" required
                           class="w-full p-2 border border-gray-800 rounded-lg bg-gray-800 text-gray-100 focus:border-pink-500 focus:ring-2 focus:ring-pink-200">
                </div>
                <div class="mb-4">
                    <label class="block mb-2">ایمیل</label>
                    <input type="email" id="email"
                           class="w-full p-2 border border-gray-800 rounded-lg bg-gray-800 text-gray-100 focus:border-pink-500 focus:ring-2 focus:ring-pink-200">
                </div>
                <div class="mb-6">
                    <label class="block mb-2">آدرس</label>
                    <textarea id="address"
                              class="w-full p-2 border border-gray-800 rounded-lg bg-gray-800 text-gray-100 focus:border-pink-500 focus:ring-2 focus:ring-pink-200"></textarea>
                </div>
                <div class="flex justify-end gap-4">
                    <button type="button" onclick="closeModal()" class="custom-btn">
                        <span class="shadow"></span>
                        <span class="edge"></span>
                        <span class="front">انصراف</span>
                    </button>
                    <button type="submit" class="custom-btn">
                        <span class="shadow"></span>
                        <span class="edge"></span>
                        <span class="front">ذخیره</span>
                    </button>
                </div>
            </form>
        </div>
    </div>

    <script src="assets/js/main.js"></script>
</body>
</html> 